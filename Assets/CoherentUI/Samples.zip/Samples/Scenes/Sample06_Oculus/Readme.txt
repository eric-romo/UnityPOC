It is not possible to create a sample scene for Oculus Rift for Unity3D 3.5
using the official Oculus SDK. Our Oculus Rift sample scene is created with
Unity3D 4 and is archived so it does not interfere with Unity3D 3.5 projects.
If you want to run the sample using Unity3D 4, just extract the supplied
scene and import the Oculus SDK package.